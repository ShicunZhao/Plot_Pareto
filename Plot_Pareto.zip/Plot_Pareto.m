clc
clear
close all
Problem_Num=29;

Algo_Name={'NSGAII','MOEAD','NSGAIII','TSNSGAII','TSKEA','LRVMA','SPAMA','LBPEA','RDMA'};

load Pareto_PF.mat
dataset_name=get_dataset_name();

for prob=1:Problem_Num
    Max1=max([Pareto_PF{prob,1};Pareto_PF{prob,2};Pareto_PF{prob,3};Pareto_PF{prob,4};Pareto_PF{prob,5};Pareto_PF{prob,6};Pareto_PF{prob,7}]); 
    Min1=min([Pareto_PF{prob,1};Pareto_PF{prob,2};Pareto_PF{prob,3};Pareto_PF{prob,4};Pareto_PF{prob,5};Pareto_PF{prob,6};Pareto_PF{prob,7}]); 
    plot(Pareto_PF{prob,1}(:,1),Pareto_PF{prob,1}(:,2),'--*','Color',[122 187 219]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,2}(:,1),Pareto_PF{prob,2}(:,2),'--*','Color',[132 186 66]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,3}(:,1),Pareto_PF{prob,3}(:,2),'--*','Color',[104 36 135]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,4}(:,1),Pareto_PF{prob,4}(:,2),'--*','Color',[219 180 40]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,5}(:,1),Pareto_PF{prob,5}(:,2),'--*','Color',[212 86 46]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,6}(:,1),Pareto_PF{prob,6}(:,2),'--*','Color',[68 133 199]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,7}(:,1),Pareto_PF{prob,7}(:,2),'--*','Color',[88 182 233]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,8}(:,1),Pareto_PF{prob,8}(:,2),'--*','Color',[37 125 139]/256,'LineWidth',2,'MarkerSize',5);     hold on;
    plot(Pareto_PF{prob,9}(:,1),Pareto_PF{prob,9}(:,2),'--r*','LineWidth',2,'MarkerSize',5);     hold on;
    legend('NSGA-II','MOEA/D','NSGA-III','TS-NSGA-II','TSKEA','LRVMA','SPAMA','LBPEA','RDMA','FontSize', 10);
    xlabel('$f_1$','interpreter','latex', 'FontSize', 20);
    ylabel('$f_2$','interpreter','latex', 'FontSize', 20);
    set(gcf,'Position',[800,300,600,600]);
    legend('Location', 'southeast');
    fig1 = figure(1);
    fig1.Renderer = 'Painters';
    name=dataset_name{prob*3-2};
    savefig(name)
    close all
end % end prob