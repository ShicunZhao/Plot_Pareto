clc
clear
close all
dbstop if error 
Problem=29;
Run=30;
addpath('function_file');


Algo_Name={'NSGAII','MOEAD','NSGAIII','TSNSGAII','TSKEA','LRVMA','SPAMA','LBPEA','RDMA'};


for algo=1:numel(Algo_Name)
    for prob=1:Problem
        data=[];
        for run=1:Run
            file_name=['Results\',Algo_Name{algo},'_Problem_',num2str(prob),'_run_',num2str(run),'.mat'];
            load(file_name);
            fit=[cell2mat({Elite.obj}')];
            data=[data;fit];
        end
        data=unique(data,'rows');
        Final_PF=NonDominationSort(data);
        Final_PF=sortrows(Final_PF,2);
        Pareto_PF{prob,algo}=Final_PF;
    end
end
save Pareto_PF Pareto_PF





