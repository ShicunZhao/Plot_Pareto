% C-metric 集合覆盖率
function score=C_Metric(Group_A,Group_B)
num_B=size(Group_B,1);
num_A=size(Group_A,1);
CmetricSet = zeros(1, num_B);
% 计算C-metric解集覆盖率
for i = 1:num_B
    solution = Group_B(i, :);
    for j = 1:num_A
        otherSolution = Group_A(j, :);
        % 判断solution是否被otherSolution支配
        if all(otherSolution<=solution) && any(otherSolution<solution)
            CmetricSet(i) = 1;
            break;
        end
    end
end
% 计算C-metric解集覆盖率
score = sum(CmetricSet) / num_B;
end % end function