%% function area
function score=IGD_Metric(PopObj,optimum,Max_Min)
% 归一化处理
max_val=Max_Min(1,:);
min_val=Max_Min(2,:);
max_val(max_val==0)=1;

optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);

score = mean(min(pdist2(optimum,PopObj),[],2));
end
