% Metric for diversity
% 衡量所获得的解集的广泛程度。
% 参数df和dl是极端解与所获得的非支配集的边界解之间的欧几里德距;di 是所获得的非支配解集中的连续解之间的欧几里德距离;

function score=Diversity_Metric(PopObj,optimum,Max_Min)
max_val=Max_Min(1,:);
min_val=Max_Min(2,:);
optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);

fmax  = max(optimum,[],1);
fmin  = min(optimum,[],1);
H     = calGrid(optimum(:,1:end-1),fmax(1:end-1),fmin(1:end-1),size(PopObj,1));
h     = H & calGrid(PopObj(:,1:end-1),fmax(1:end-1),fmin(1:end-1),size(PopObj,1));
score = calM(h,H)./calM(H,H);
end



function h = calGrid(P,fmax,fmin,div)
% Determine whether each grid has at least one point

[N,M] = size(P);
d     = (fmax-fmin)./div;
GLoc  = ceil((P-repmat(fmin,N,1))./repmat(d,N,1));
GLoc  = max(1,GLoc);
h     = zeros(M,div);
for i = 1 : M
    h(i,:) = ismember(1:div,GLoc(:,i));
end
end

function m = calM(h,H)
% Calculate the value function m()

M = size(h,1);
h = [ones(M,1),h,ones(M,1)];
H = [ones(M,1),H,ones(M,1)];
m = 0;
for i = 1 : M
    for j = 2 : size(h,2)-1
        if H(i,j)
            if h(i,j)
                if h(i,j-1)
                    if h(i,j+1)
                        m = m + 1;
                    else
                        m = m + 0.67;
                    end
                else
                    if h(i,j+1)
                        m = m + 0.67;
                    else
                        m = m + 0.75;
                    end
                end
            else
                if h(i,j-1)
                    if h(i,j+1)
                        m = m + 0.75;
                    else
                        m = m + 0.5;
                    end
                else
                    if h(i,j+1)
                        m = m + 0.5;
                    else
                        m = m + 0;
                    end
                end
            end
        end
    end
end
end