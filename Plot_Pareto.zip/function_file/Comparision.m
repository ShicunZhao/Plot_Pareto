clc
clear
close all
dbstop if error
Algorithm_Name={'NSGAII','NSGAIII','MOEAD','SPEAII','PESAII'};
Problem_Num=28;
Runs=5;
Algo_Num=4;
obj_num=2;
%% 获取所有算法的计算结果  去除重复的适应值
for prob=1:Problem_Num
    Final_PF=[];
    %Final_FOM=[];
    for algo=1:Algo_Num
        for run=1:Runs
            data_name=['data\',Algorithm_Name{algo},'_Problem_',num2str(prob),'_run_',num2str(run),'.mat'];
            load(data_name)
            Final_PF=[Final_PF;PF];
        end % end run
    end % end algo
    Final_PF=unique(Final_PF,'rows');
    Final_PF=NonDominationSort(Final_PF);
    Pareto_PF{prob}=Final_PF;
end % end prob

%% 获取每个算法的处理结果  去除重复的适应值，且进行非支配排序
for algo=1:Algo_Num
    for prob=1:Problem_Num
        Algo=[];
        for run=1:Runs
            data_name=['data\',Algorithm_Name{algo},'_Problem_',num2str(prob),'_run_',num2str(run),'.mat'];
            load(data_name)
            Algo=[Algo; PF];
        end % end run
        Algo=unique(Algo,'rows');
        fit=NonDominationSort(Algo);
        Algo_PF{algo,prob}=fit;
    end % end prob
end  % end algo

%% 获取最大最小值，便于归一化处理
for prob=1:Problem_Num
    max_val=max(Pareto_PF{prob});
    min_val=min(Pareto_PF{prob});
    for algo=1:Algo_Num
        max_val=max(max_val, max(Algo_PF{algo,prob}));
        min_val=min(min_val, min(Algo_PF{algo,prob}));
    end % end algo
    Max_Min{prob}=[min_val;max_val];
end  % end prob

%% 计算相关指标
for prob=1:Problem_Num
    for algo=1:Algo_Num
        algo_PF=Algo_PF{algo,prob};  % 算法跑出的PF解集
        Prob_PF=Pareto_PF{prob};     % 所有算法跑出的PF解集  最优PF解集
        % GD 基于最终适应值fitness  越小越好
        GD_value=GD_Metric(algo_PF,Prob_PF,Max_Min{prob});
        GD_Table(prob,algo)=GD_value;
        % IGD 基于最终适应值fitness 越小越好
        IGD_value=IGD_Metric(algo_PF,Prob_PF,Max_Min{prob});
        IGD_Table(prob,algo)=IGD_value;
        % IGDp Inverted generational distance plus (IGD+)
        IGDp_value=IGDp_Metric(algo_PF,Prob_PF,Max_Min{prob});
        IGDp_Table(prob,algo)=IGDp_value;
        % Spacing 基于最终适应值fitness  越小说明解集越均匀 为0 说明只有一个解
        Spacing_value=Spacing_Metric(algo_PF,Prob_PF,Max_Min{prob});
        Spacing_Table(prob,algo)=Spacing_value;
        % HV 预计最终适应值的计算方式  越大越好
        HV_value=HV_Metric(algo_PF,Prob_PF,Max_Min{prob});
        HV_Table(prob,algo)=HV_value;
        %  Coverage_over_Pareto_front  基于适应值 越大越好[0 1]之间
        COPF_value=COPF_Metric(algo_PF,Prob_PF,Max_Min{prob});
        COPF_Table(prob,algo)=COPF_value;
        %  Averaged Hausdorff distance  基于适应值 越小越好
        DeltaP_value=DeltaP_Metric(algo_PF,Prob_PF,Max_Min{prob});
        DeltaP_Table(prob,algo)=DeltaP_value;
        % Diversity Metric 基于适应值   越大越好（maybe）
        Diversity_value=Diversity_Metric(algo_PF,Prob_PF,Max_Min{prob});
        Diversity_Table(prob,algo)=Diversity_value;
    end % end prob
end  % end algo
% 计算相互之间的集合覆盖率 C(A,B)=1表示B中所有解都被A中的一些解所支配；C(A,B)=0表示B中没有解被A中的任一解所支配。
k=1;
for i=1:Algo_Num
    for j=(i+1):Algo_Num
        if i~=j
            for prob=1:Problem_Num %越大越好
                data_1=Algo_PF{i,prob};
                data_2=Algo_PF{j,prob};
                score=C_Metric(data_1,data_2);
                C_table(prob,k)=score;
                score=C_Metric(data_2,data_1);
                C_table(prob,k+1)=score;
            end
        end
        k=k+2;
    end
end  % end i
%% function area
function [objectiveValue] = NonDominationSort(objectiveValue)       %快速非支配排序，并排序

front = 1;
Front(front).f = [];
individual = [];
len = size(objectiveValue, 1);
rank = zeros(len, 1);

%找出等级最高的非支配解集
for i = 1:len  % popsize
    individual(i).n = 0;    %n是个体i被支配的个体数量
    individual(i).p = [];   %p是被个体i支配的个体集合
    
    for j = 1:size(objectiveValue, 1)
        if all(objectiveValue(j, :) <= objectiveValue(i, :)) && any(objectiveValue(j, :) < objectiveValue(i, :))
            individual(i).n = individual(i).n + 1;      %说明i受j支配，相应的n加1
        elseif all(objectiveValue(i, :) <= objectiveValue(j, :)) && any(objectiveValue(i, :) < objectiveValue(j, :))
            individual(i).p = [individual(i).p, j];     %说明i支配j，把j加入i的支配集合中
        end
        
    end
    % 如果没有支配个体I的个体
    if individual(i).n == 0     %个体i的非支配等级最高，属于当前的最优解
        rank(i) = 1;
        Front(front).f = [Front(front).f, i];   %等级为1的非支配解集
    end
end  % end for i = 1:len  % popsize

%给其他个体分级
while ~isempty(Front(front).f)  %如果front非空
    Q = [];     %存放下一个front集合
    for i = 1:length(Front(front).f)
        if ~isempty(individual(Front(front).f(i)).p)    %个体i有自己所支配的解集
            for j = 1:length(individual(Front(front).f(i)).p)  % 个体i支配的编号
                individual(individual(Front(front).f(i)).p(j)).n = individual(individual(Front(front).f(i)).p(j)).n - 1;
                if individual(individual(Front(front).f(i)).p(j)).n == 0    %将非支配集合放入Q
                    rank(individual(Front(front).f(i)).p(j)) = front + 1;
                    Q = [Q, individual(Front(front).f(i)).p(j)];
                end
            end
        end
    end
    front = front + 1;
    Front(front).f = Q;
end  % end while ~isempty(Front(front).f)

% [~, index] = sort(rank);
objectiveValue=objectiveValue(rank==1,:);
end  % end function

