function score=Spacing_Metric(PopObj,optimum,Max_Min)
max_val=Max_Min(1,:);
min_val=Max_Min(2,:);
optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);
solution_num=size(PopObj,1);
if solution_num>1
    Distance = pdist2(PopObj,PopObj,'cityblock');
    Distance(logical(eye(size(Distance,1)))) = inf;
    score = std(min(Distance,[],2));
else
    score=999;
end
end