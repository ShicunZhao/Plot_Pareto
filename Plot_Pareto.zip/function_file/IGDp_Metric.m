%% function area
function score=IGDp_Metric(PopObj,optimum,Max_Min)
% 归一化处理
max_val=Max_Min(1,:);
min_val=Max_Min(2,:);
optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);

[Nr,M] = size(optimum);
[N,~]  = size(PopObj);
delta  = zeros(Nr,1);
for i = 1 : Nr
    delta(i) = min(sqrt(sum(max(PopObj - repmat(optimum(i,:),N,1),zeros(N,M)).^2,2)));
end
score = mean(delta);
end
