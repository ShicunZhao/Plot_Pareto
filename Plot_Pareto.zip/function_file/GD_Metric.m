% GD指标含义：解集P中的每个点到参考集P *中的平均最小距离表示。GD值越小，表示收敛性越好。
function score=GD_Metric(PopObj,optimum,Max_Min)  % 不需要进行归一化处理
max_val=Max_Min(1,:);
max_val(max_val==0)=1;
min_val=Max_Min(2,:);
optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);

Distance = min(pdist2(PopObj,optimum),[],2);
score    = norm(Distance)/length(Distance);
end