
% 基于自变量的评价方法
function score=Spread_Metric(PopObj,optimum)
% max_val=max(optimum);
% min_val=min(optimum);
% optimum=(optimum-min_val)./(max_val-min_val);
% PopObj=(PopObj-min_val)./(max_val-min_val);

Dis1  = pdist2(PopObj,PopObj);
Dis1(logical(eye(size(Dis1,1)))) = inf;
[~,E] = max(optimum,[],1);
Dis2  = pdist2(optimum(E,:),PopObj);
d1    = sum(min(Dis2,[],2));
d2    = mean(min(Dis1,[],2));
score = (d1+sum(abs(min(Dis1,[],2)-d2))) / (d1+(size(PopObj,1)-size(PopObj,2))*d2);
end