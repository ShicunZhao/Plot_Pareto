% Averaged Hausdorff distance
% Averaged Hausdorff distance是用于衡量多目标优化算法的性能的一种指标。
% 它用于比较算法找到的非支配解集与真实Pareto前沿之间的差异。
% Averaged Hausdorff distance越小表示算法找到的解集与真实Pareto前沿越接近，因此越小越好。

function score=DeltaP_Metric(PopObj,optimum,Max_Min)
max_val=Max_Min(1,:);
min_val=Max_Min(2,:);
optimum=(optimum-min_val)./(max_val-min_val);
PopObj=(PopObj-min_val)./(max_val-min_val);
Distance = pdist2(optimum,PopObj);
score    = max(mean(min(Distance,[],1)),mean(min(Distance,[],2)));
end